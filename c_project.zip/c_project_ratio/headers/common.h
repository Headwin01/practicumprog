#ifndef __COMMON__
#define __COMMON__

typedef double DType; /* Double real type for application */

typedef short HType;    /* Short integer type for application */

typedef long long IType;    /* Integer type for application */

typedef unsigned long NType; /* Unsigned type for application */

#endif